#!/usr/bin/env python3

from setuptools import setup


setup(name='gym_kinova_gripper', version='0.0.1', install_requires=['gym'])